package GestionScolaire.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import GestionScolaire.metier.dao.EtablissementDao;
import GestionScolaire.metier.dao.MatiereDao;
import GestionScolaire.metier.dao.MatiereProfesseurDao;
import GestionScolaire.metier.dao.MatiereSalleDao;
import GestionScolaire.metier.dao.ProfesseurDao;
import GestionScolaire.metier.dao.SalleDao;
import GestionScolaire.metier.dao.UserDao;
import GestionScolaire.metier.model.Adresse;
import GestionScolaire.metier.model.Civilite;
import GestionScolaire.metier.model.CouleurMatiere;
import GestionScolaire.metier.model.Etablissement;
import GestionScolaire.metier.model.Matiere;
import GestionScolaire.metier.model.MatiereSalle;
import GestionScolaire.metier.model.Professeur;
import GestionScolaire.metier.model.ProfesseurMatiere;
import GestionScolaire.metier.model.Salle;
import GestionScolaire.metier.model.TypeEtablissement;
import GestionScolaire.metier.model.User;


@ContextConfiguration(locations = "classpath:applicationContext.xml")
@RunWith(SpringJUnit4ClassRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestGestionScolaire {
	
	
	@Autowired
	private SalleDao salleDao;
	@Autowired
	private MatiereDao matiereDao;
	@Autowired
	private MatiereSalleDao matiereSalleDao;
	@Autowired
	private ProfesseurDao professeurDao;
	@Autowired
	private UserDao userDao;
	@Autowired
	private MatiereProfesseurDao matiereProfesseurDao;
	@Autowired
	private EtablissementDao etablissementDao;

	@Test
	public void apopulate() {
		
		Adresse adrProf = new Adresse();
		adrProf.setRue("rue de la paix");
		adrProf.setCodePostal("75001");
		adrProf.setPays("France");
		adrProf.setVille("Paris");
		
		Adresse adrUser = new Adresse();
		adrProf.setRue("rue de la paix");
		adrProf.setCodePostal("4500");
		adrProf.setPays("Maroc");
		adrProf.setVille("Marrakech");
		
		
		Matiere matiere = new Matiere();
		matiere.setCouleur(CouleurMatiere.Bleu);
		matiere.setNom("maths");
		
		Salle salle=new Salle();
		salle.setCapacite(10);
		salle.setNom("Violette");
		
		MatiereSalle matiereSalle=new MatiereSalle();
		matiereSalle.setMatiere(matiere);
		matiereSalle.setSalle(salle);
		
		
		Calendar cal = GregorianCalendar.getInstance();
		cal.set(2014, Calendar.APRIL, 18, 15, 20, 00);
		Date dateNais = cal.getTime();
		
		Professeur professeur=new Professeur();
		professeur.setAdresse(adrProf);
		professeur.setCivilite(Civilite.Mme);
		professeur.setDateNaissance(dateNais);
		professeur.setNom("Marsaud");
		professeur.setPrenom("safia");
		
		
		Professeur professeur1=new Professeur();
		professeur1.setAdresse(adrProf);
		professeur1.setCivilite(Civilite.Mme);
		professeur1.setDateNaissance(dateNais);
		professeur1.setNom("Lakder");
		professeur1.setPrenom("Hannen");
		
		
		
		User userAdmin=new User();
		userAdmin.setAdresse(adrUser);
		userAdmin.setCivilite(Civilite.Mr);
		userAdmin.setLogin("admin123");
		userAdmin.setMotDePasse("123456789");
		userAdmin.setNom("solbiac");
		userAdmin.setPrenom("cedric");
		userAdmin.setAdmin(true);
		
		ProfesseurMatiere professeurMatiere=new ProfesseurMatiere();
		professeurMatiere.setMatiere(matiere);
		professeurMatiere.setProfesseur(professeur);

		userDao.create(userAdmin);
		professeurDao.create(professeur);
		professeurDao.create(professeur1);
		matiereDao.create(matiere);
		salleDao.create(salle);
		matiereSalleDao.create(matiereSalle);
		matiereProfesseurDao.create(professeurMatiere);
		
		
		
		Adresse adrEtablissement = new Adresse();
		adrEtablissement.setRue("rue de la paix");
		adrEtablissement.setCodePostal("75001");
		adrEtablissement.setPays("France");
		adrEtablissement.setVille("Paris");
		
		Etablissement etablissement = new Etablissement();
		etablissement.setNomEtablissement("ajc");
		etablissement.setNumTel("0688888888");
		etablissement.setTypeEtablissement(TypeEtablissement.College);
		etablissement.setAdresse(adrEtablissement);
		etablissement.setLogo("C:/Users/Safia/workspace/GestionScolaire-persistence/Pictures/img1.jpg");
		etablissementDao.create(etablissement);
		
	}
}
