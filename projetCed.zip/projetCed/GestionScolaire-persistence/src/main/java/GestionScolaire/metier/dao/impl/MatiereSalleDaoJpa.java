package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.MatiereSalleDao;
import GestionScolaire.metier.model.MatiereSalle;

@Transactional
@Repository
public class MatiereSalleDaoJpa implements MatiereSalleDao{

	
	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;
	
	@Override
	public MatiereSalle find(Long id) {
		return em.find(MatiereSalle.class, id);
	}

	@Override
	public List<MatiereSalle> findAll() {
		Query query = em.createQuery("from MatiereSalle ms");
		return query.getResultList();
	}

	@Override
	public void create(MatiereSalle matiereSalle) {
		em.persist(matiereSalle);
		
	}

	@Override
	public MatiereSalle update(MatiereSalle matiereSalle) {
		return em.merge(matiereSalle);
	}

	@Override
	public void delete(MatiereSalle matiereSalle) {
		em.remove(em.merge(matiereSalle));
	}

	@Override
	public void delete(Long id) {
		MatiereSalle matiereSalle = find(id);
		em.remove(matiereSalle);
		
	}

}
