package GestionScolaire.metier.model;

public enum TypeUser {
Admin,Utilisateur
}
