package GestionScolaire.metier.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "cours")
public class EmploiDuTempsClasse {
	private Long id;
	private Classe classe ;
	private Professeur professeur;
	private Matiere matiere;
	private Salle salle;
	private Date heureDebut;
	private Date heureFin;
	private JourSemaine jour;
	private int version;
	
	public EmploiDuTempsClasse() {
		super();
	}
	
	public EmploiDuTempsClasse(Classe classe, Professeur professeur, Matiere matiere, Salle salle, Date heureDebut,
			Date heureFin, JourSemaine jour) {
		super();
		this.classe = classe;
		this.professeur = professeur;
		this.matiere = matiere;
		this.salle = salle;
		this.heureDebut = heureDebut;
		this.heureFin = heureFin;
		this.jour = jour;
	}

	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	

	@ManyToOne
	@JoinColumn(name = "classe_id")
	public Classe getClasse() {
		return classe;
	}
	public void setClasse(Classe classe) {
		this.classe = classe;
	}
	
	@ManyToOne
	@JoinColumn(name = "professeur_id")
	public Professeur getProfesseur() {
		return professeur;
	}

	public void setProfesseur(Professeur professeur) {
		this.professeur = professeur;
	}

	@ManyToOne
	@JoinColumn(name = "matiere_id")
	public Matiere getMatiere() {
		return matiere;
	}

	public void setMatiere(Matiere matiere) {
		this.matiere = matiere;
	}

	@ManyToOne
	@JoinColumn(name = "salle_id")
	public Salle getSalle() {
		return salle;
	}

	public void setSalle(Salle salle) {
		this.salle = salle;
	}

	@Version
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	
	@Column(name = "heureDebut")
	@Temporal(TemporalType.TIME)
	@DateTimeFormat(pattern="HH-mm")
	public Date getHeureDebut() {
		return heureDebut;
	}
	public void setHeureDebut(Date heureDebut) {
		this.heureDebut = heureDebut;
	}
	
	@Column(name = "HeureFin")
	@Temporal(TemporalType.TIME)
	@DateTimeFormat(pattern="HH-mm")
	public Date getHeureFin() {
		return heureFin;
	}

	public void setHeureFin(Date heureFin) {
		this.heureFin = heureFin;
	}
	public JourSemaine getJour() {
		return jour;
	}

	public void setJour(JourSemaine jour) {
		this.jour = jour;
	}
}
