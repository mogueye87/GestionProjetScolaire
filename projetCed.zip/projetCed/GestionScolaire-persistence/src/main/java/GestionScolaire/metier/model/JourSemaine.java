package GestionScolaire.metier.model;

public enum JourSemaine {
Lundi,Mardi,Mercredi,Jeudi,Vendredi
}
