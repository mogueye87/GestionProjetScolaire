package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.MatiereSalleDao;
import GestionScolaire.metier.dao.SalleDao;
import GestionScolaire.metier.model.MatiereSalle;
import GestionScolaire.metier.model.Salle;


@Transactional// utiliser EM
@Repository //utiliser Autowired
public class SalleDaoJpa implements SalleDao{

	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;

	@Autowired
	private MatiereSalleDao matiereSalleDao;
	
	@Autowired
	private SalleDao salleDao;
	
	@Override
	public Salle find(Long id) {
		return em.find(Salle.class, id);
	}

	@Override
	public List<Salle> findAll() {
		Query query = em.createQuery("from Salle s");
		return query.getResultList();
	}

	@Override
	public Salle find(String name) {
		Query query = em.createQuery("from Salle s where s.nom = :nom");
		query.setParameter("nom", name);
		List<Salle> salle = query.getResultList();
		return salle.size() > 0 ? salle.get(0) : null;
	}
	
	
	
	@Override
	public void create(Salle salle) {
		em.persist(salle);
		
	}

	@Override
	public Salle update(Salle salle) {
		return em.merge(salle);
	}

	@Override
	public void delete(Salle salle) {
		
		for (MatiereSalle matiereSalle : salle.getMatieres()) {
			matiereSalleDao.delete(matiereSalle);
		}
				
		em.remove(em.merge(salle));
		
	}

	@Override
	public void delete(Long id) {
		
		Salle salle = find(id);
		for (MatiereSalle matiereSalle : salle.getMatieres()) {
			matiereSalleDao.delete(matiereSalle);
		}
		em.remove(em.merge(salle));
		
	}
}
