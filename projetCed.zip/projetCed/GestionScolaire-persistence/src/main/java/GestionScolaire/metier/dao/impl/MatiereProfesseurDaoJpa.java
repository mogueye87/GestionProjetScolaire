package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.MatiereProfesseurDao;
import GestionScolaire.metier.model.MatiereSalle;
import GestionScolaire.metier.model.Professeur;
import GestionScolaire.metier.model.ProfesseurMatiere;

@Transactional
@Repository
public class MatiereProfesseurDaoJpa implements MatiereProfesseurDao{

	
	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;
	
	
	@Override
	public ProfesseurMatiere find(Long id) {
		return em.find(ProfesseurMatiere.class, id);
	}

	@Override
	public List<ProfesseurMatiere> findAll() {
		Query query = em.createQuery("from ProfesseurMatiere pm");
		return query.getResultList();
	}

	@Override
	public void create(ProfesseurMatiere professeurMatiere) {
		em.persist(professeurMatiere);
	}

	@Override
	public ProfesseurMatiere update(ProfesseurMatiere professeurMatiere) {
		return em.merge(professeurMatiere);
	}

	@Override
	public void delete(ProfesseurMatiere professeurMatiere) {
		em.remove(em.merge(professeurMatiere));
		
	}

	@Override
	public void delete(Long id) {
		ProfesseurMatiere professeurMatiere = find(id);
		em.remove(professeurMatiere);
	}

//	@Override
//	public List<ProfesseurMatiere> findByProfId(Long idProfesseur) {
//		Query query = em.createQuery("from ProfesseurMatiere pm where pm.professeur.id = :id");
//		query.setParameter("id", idProfesseur);
//		List<ProfesseurMatiere> professeurMatieres= query.getResultList();
//		return professeurMatieres.size() > 0 ? professeurMatieres : null;
//	}

	
}
