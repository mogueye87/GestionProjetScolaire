package GestionScolaire.metier.model;

public enum Civilite {
 Mme,Mlle,Mr
}
