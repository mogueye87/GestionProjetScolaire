package GestionScolaire.metier.dao;

import GestionScolaire.metier.model.Matiere;

public interface MatiereDao extends Dao<Matiere,Long>{

	Matiere find(String name);
}
