package GestionScolaire.metier.model;


import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Version;



@Entity
@Table(name = "Establishment")
public class Etablissement {
	
	private Long idEtablissement;
	private String nomEtablissement;
	private TypeEtablissement typeEtablissement;
	private String numTel;
	private String logo;
	private int version;
	private Adresse adresse;
	private List<User> users;

	
	public Etablissement() {
		super();
	}
	
	public Etablissement( String nomEtablissement,
			GestionScolaire.metier.model.TypeEtablissement typeEtablissement, String numTel, String logo) {
		super();
		this.nomEtablissement = nomEtablissement;
		this.typeEtablissement = typeEtablissement;
		this.numTel = numTel;
		this.logo = logo;
	}

	@Id
	@GeneratedValue
	public Long getIdEtablissement() {
		return idEtablissement;
	}

	public void setIdEtablissement(Long idEtablissement) {
		this.idEtablissement = idEtablissement;
	}
	public String getNomEtablissement() {
		return nomEtablissement;
	}

	public void setNomEtablissement(String nomEtablissement) {
		this.nomEtablissement = nomEtablissement;
	}
	
	public TypeEtablissement getTypeEtablissement() {
		return typeEtablissement;
	}

	public void setTypeEtablissement(TypeEtablissement typeEtablissement) {
		this.typeEtablissement = typeEtablissement;
	}
	public String getNumTel() {
		return numTel;
	}

	public void setNumTel(String numTel) {
		this.numTel = numTel;
	}

	
	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}
	@Version
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}

	@Embedded
	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	@OneToMany(mappedBy = "etablissement", fetch = FetchType.EAGER)
	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}
	
	
	
}
