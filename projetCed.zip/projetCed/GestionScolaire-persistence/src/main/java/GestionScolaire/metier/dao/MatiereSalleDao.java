package GestionScolaire.metier.dao;

import GestionScolaire.metier.model.MatiereSalle;

public interface MatiereSalleDao extends Dao<MatiereSalle,Long> {

}
