package GestionScolaire.metier.dao;


import GestionScolaire.metier.model.User;

public interface UserDao extends Dao<User,Long>{

	User find(String name);

}
