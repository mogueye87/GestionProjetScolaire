package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.EmploiDuTempsClasseDao;
import GestionScolaire.metier.model.EmploiDuTempsClasse;
import GestionScolaire.metier.model.MatiereSalle;

@Transactional
@Repository
public class EmploiDuTempsClasseDaoJpa implements EmploiDuTempsClasseDao {

	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;
	
	
	@Override
	public EmploiDuTempsClasse find(Long id) {

		return em.find(EmploiDuTempsClasse.class, id);
	}

	@Override
	public List<EmploiDuTempsClasse> findAll() {
		Query query = em.createQuery("from EmploiDuTempsClasse ec");
		return query.getResultList();
	}

	@Override
	public void create(EmploiDuTempsClasse emploiDuTempsClasse) {
		em.persist(emploiDuTempsClasse);
	}

	@Override
	public EmploiDuTempsClasse update(EmploiDuTempsClasse emploiDuTempsClasse) {
		return em.merge(emploiDuTempsClasse);
	}

	@Override
	public void delete(EmploiDuTempsClasse emploiDuTempsClasse) {
		em.remove(em.merge(emploiDuTempsClasse));
		
	}

	@Override
	public void delete(Long id) {
		EmploiDuTempsClasse emploiDuTempsClasse = find(id);
		em.remove(emploiDuTempsClasse);
		
	}

	

}
