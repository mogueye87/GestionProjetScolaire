package GestionScolaire.metier.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
public class Classe {
	private Long id;
	private String nom;
	private Professeur professeur;
	private List<EmploiDuTempsClasse> emploiDuTempsClasses;
	private int version;
	
	public Classe() {
		super();
	}
	
	public Classe(String nom, Professeur professeur, List<EmploiDuTempsClasse> emploiDuTempsClasses) {
		super();
		this.nom = nom;
		this.professeur = professeur;
		this.emploiDuTempsClasses = emploiDuTempsClasses;
	}
	
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "professeur_id")
	public Professeur getProfesseur() {
		return professeur;
	}

	public void setProfesseur(Professeur professeur) {
		this.professeur = professeur;
	}

	@OneToMany(mappedBy = "classe", fetch = FetchType.EAGER)		
	public List<EmploiDuTempsClasse> getEmploiDuTempsClasses() {
		return emploiDuTempsClasses;
	}

	public void setEmploiDuTempsClasses(List<EmploiDuTempsClasse> emploiDuTempsClasses) {
		this.emploiDuTempsClasses = emploiDuTempsClasses;
	}

	@Version
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}
	
	
	
}
