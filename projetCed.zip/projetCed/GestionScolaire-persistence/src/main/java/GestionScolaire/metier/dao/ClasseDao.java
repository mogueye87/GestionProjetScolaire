package GestionScolaire.metier.dao;

import GestionScolaire.metier.model.Classe;

public interface ClasseDao extends Dao<Classe,Long>{

	Classe find(String name);

}
