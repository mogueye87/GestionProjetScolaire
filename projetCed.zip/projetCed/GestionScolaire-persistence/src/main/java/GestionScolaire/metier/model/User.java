package GestionScolaire.metier.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@DiscriminatorValue("User")
public class User extends Personne{
	
	private String login;
	private String motDePasse;
	private boolean admin;
	private Etablissement etablissement;
	
	public User() {
		super();
	}

	public User(String login, String motDePasse, boolean admin) {
		super();
		this.login = login;
		this.motDePasse = motDePasse;
		this.admin = admin;
	}

	@Column(name = "login", length = 50, unique = true)
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	@Column(name = "motdepasse", length = 50)
	public String getMotDePasse() {
		return motDePasse;
	}

	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}

	@Column(name = "admin")
	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	
	

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "etablissement_id")
	public Etablissement getetablissement() {
		return etablissement;
	}

	public void setetablissement(Etablissement etablissement) {
		this.etablissement = etablissement;
	}


	
}
