package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.ProfesseurDao;
import GestionScolaire.metier.model.Matiere;
import GestionScolaire.metier.model.Professeur;

@Transactional
@Repository
public class ProfesseurDaoJpa implements ProfesseurDao{

	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;
	
	@Override
	public Professeur find(Long id) {
		return em.find(Professeur.class, id);
	}

	@Override
	public List<Professeur> findAll() {
		Query query = em.createQuery("from Professeur p");
		return query.getResultList();
	}

	@Override
	public void create(Professeur professeur) {
		em.persist(professeur);
		
	}

	@Override
	public Professeur update(Professeur professeur) {
		return em.merge(professeur);
	}

	@Override
	public void delete(Professeur professeur) {
		em.remove(em.merge(professeur));
	}

	@Override
	public void delete(Long id) {
		Professeur professeur = find(id);
		em.remove(em.merge(professeur));
	}

	@Override
	public Professeur find(String name) {
		Query query = em.createQuery("from Matiere m where m.nom = :nom");
		query.setParameter("nom", name);
		List<Professeur> professeur = query.getResultList();
		return professeur.size() > 0 ? professeur.get(0) : null;
	}

}
