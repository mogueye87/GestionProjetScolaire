package GestionScolaire.metier.dao;

import GestionScolaire.metier.model.Etablissement;

public interface EtablissementDao extends Dao <Etablissement,Long> {
	
	//fonction recuper un objet de type etablissament et la recherche pat name
	Etablissement find(String name);

}
