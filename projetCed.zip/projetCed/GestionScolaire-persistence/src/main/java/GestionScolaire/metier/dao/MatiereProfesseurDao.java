package GestionScolaire.metier.dao;

import java.util.List;

import GestionScolaire.metier.model.Professeur;
import GestionScolaire.metier.model.ProfesseurMatiere;

public interface MatiereProfesseurDao extends Dao<ProfesseurMatiere,Long> {
	
//	List<ProfesseurMatiere> findByProfId(Long id);

}
