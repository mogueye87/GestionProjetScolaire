package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.UserDao;
import GestionScolaire.metier.model.User;

@Transactional
@Repository
public class UserDaoJpa implements UserDao {

	
	
	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;
	
	@Override
	public User find(Long id) {
		return em.find(User.class, id);
	}

	@Override
	public List<User> findAll() {
		Query query = em.createQuery("from User u");
		return query.getResultList();
	}

	@Override
	public void create(User user) {
		em.persist(user);
		
	}

	@Override
	public User update(User user) {
		return em.merge(user);
	}

	@Override
	public void delete(User user) {
		em.remove(em.merge(user));
		
	}

	@Override
	public void delete(Long id) {
		User user=find(id);
		em.remove(em.merge(user));
		
	}

	@Override
	public User find(String name) {

		Query query = em.createQuery("from Matiere m where m.nom = :nom");
		query.setParameter("nom", name);
		List<User> user = query.getResultList();
		return user.size() > 0 ? user.get(0) : null;
	}

}
