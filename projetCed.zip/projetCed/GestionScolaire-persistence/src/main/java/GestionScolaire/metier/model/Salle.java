package GestionScolaire.metier.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
public class Salle {
	
	private Long id;
	private String nom;
	private int capacite;
	private List<MatiereSalle> matieres;
	private List<EmploiDuTempsClasse> emploiDuTempsClasses;
	private int version;
	
	

	public Salle(String nom, int capacite, List<MatiereSalle> matieres,
			List<EmploiDuTempsClasse> emploiDuTempsClasses) {
		super();
		this.nom = nom;
		this.capacite = capacite;
		this.matieres = matieres;
		this.emploiDuTempsClasses = emploiDuTempsClasses;
	}

	public Salle() {
		super();
	}
	
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "nom", length = 100)
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getCapacite() {
		return capacite;
	}

	public void setCapacite(int capacite) {
		this.capacite = capacite;
	}

	@OneToMany(mappedBy = "salle", fetch = FetchType.EAGER)
	public List<MatiereSalle> getMatieres() {
		return matieres;
	}

	public void setMatieres(List<MatiereSalle> matieres) {
		this.matieres = matieres;
	}

	@Version
	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@OneToMany(mappedBy = "salle", fetch = FetchType.EAGER)
	public List<EmploiDuTempsClasse> getEmploiDuTempsClasses() {
		return emploiDuTempsClasses;
	}

	public void setEmploiDuTempsClasses(List<EmploiDuTempsClasse> emploiDuTempsClasses) {
		this.emploiDuTempsClasses = emploiDuTempsClasses;
	}
	

	
	
	
}
