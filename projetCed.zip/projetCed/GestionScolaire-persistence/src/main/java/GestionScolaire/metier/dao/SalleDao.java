package GestionScolaire.metier.dao;

import GestionScolaire.metier.model.Salle;

public interface SalleDao extends Dao<Salle,Long>{

	Salle find(String name);
}
