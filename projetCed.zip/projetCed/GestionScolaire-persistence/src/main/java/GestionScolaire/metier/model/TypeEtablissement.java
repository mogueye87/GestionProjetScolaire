package GestionScolaire.metier.model;

public enum TypeEtablissement {Ecole,College,Lycee}
