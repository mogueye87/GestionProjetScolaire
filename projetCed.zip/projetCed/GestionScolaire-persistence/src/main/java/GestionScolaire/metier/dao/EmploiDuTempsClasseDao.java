package GestionScolaire.metier.dao;

import GestionScolaire.metier.model.EmploiDuTempsClasse;
import GestionScolaire.metier.model.ProfesseurMatiere;

public interface EmploiDuTempsClasseDao extends Dao<EmploiDuTempsClasse,Long> {

	
}
