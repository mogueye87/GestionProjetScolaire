package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.EtablissementDao;
import GestionScolaire.metier.model.Etablissement;
import GestionScolaire.metier.model.Matiere;
@Transactional
@Repository
public class EtablissementDaoJpa implements EtablissementDao{

	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;
	
	@Override
	public Etablissement find(Long id) {

		return em.find(Etablissement.class, id);

	}

	@Override
	public List<Etablissement> findAll() {
		Query query = em.createQuery("from Etablissement e");
		return query.getResultList();
	}

	@Override
	public void create(Etablissement etablissement) {
		em.persist(etablissement);
		
	}

	@Override
	public Etablissement update(Etablissement etablissement) {
		return em.merge(etablissement);
	}

	@Override
	public void delete(Etablissement etablissement) {
		em.remove(em.merge(etablissement));
	}

	@Override
	public void delete(Long id) {
		Etablissement etablissement = find(id);
		em.remove(em.merge(etablissement));
	}

	@Override
	public Etablissement find(String name) {
		Query query = em.createQuery("from Etablissement e where e.nom = :nom");
		query.setParameter("nom", name);
		List<Etablissement> etablissement = query.getResultList();
		return etablissement.size() > 0 ? etablissement.get(0) : null;
	}

}
