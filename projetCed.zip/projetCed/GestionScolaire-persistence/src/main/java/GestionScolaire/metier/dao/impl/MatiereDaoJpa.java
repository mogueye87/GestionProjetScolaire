package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.EmploiDuTempsClasseDao;
import GestionScolaire.metier.dao.MatiereDao;
import GestionScolaire.metier.dao.MatiereProfesseurDao;
import GestionScolaire.metier.dao.MatiereSalleDao;
import GestionScolaire.metier.model.EmploiDuTempsClasse;
import GestionScolaire.metier.model.Matiere;
import GestionScolaire.metier.model.MatiereSalle;
import GestionScolaire.metier.model.ProfesseurMatiere;
@Transactional
@Repository
public class MatiereDaoJpa implements MatiereDao {

		
	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;

	@Autowired
	private MatiereSalleDao matiereSalleDao ;
	@Autowired
	private MatiereProfesseurDao  matiereProfesseurDao;
	@Autowired
	private EmploiDuTempsClasseDao emploiDuTempsClasseDao;
	
	@Override
	public Matiere find(Long id) {

		return em.find(Matiere.class, id);
	}

	@Override
	public List<Matiere> findAll() {
		Query query = em.createQuery("from Matiere m");
		return query.getResultList();
	}

	@Override
	public void create(Matiere matiere) {
		em.persist(matiere);
		
	}

	@Override
	public Matiere update(Matiere matiere) {
		return em.merge(matiere);

	}

	@Override
	public void delete(Matiere matiere) {
		for (MatiereSalle matiereSalle : matiere.getSalles()) {
			matiereSalleDao.delete(matiereSalle);
		}
		for (ProfesseurMatiere professeurMatiere : matiere.getProfesseurs()) {
			matiereProfesseurDao.delete(professeurMatiere);
		}
		for (EmploiDuTempsClasse emploiDuTempsClasse : matiere.getEmploiDuTempsClasses()) {
			emploiDuTempsClasseDao.delete(emploiDuTempsClasse);
		}
		
		em.remove(em.merge(matiere));
	}

	@Override
	public void delete(Long id) {
		Matiere matiere = find(id);
		for (MatiereSalle matiereSalle : matiere.getSalles()) {
			matiereSalleDao.delete(matiereSalle);
		}
		for (ProfesseurMatiere professeurMatiere : matiere.getProfesseurs()) {
			matiereProfesseurDao.delete(professeurMatiere);
		}
		for (EmploiDuTempsClasse emploiDuTempsClasse : matiere.getEmploiDuTempsClasses()) {
			emploiDuTempsClasseDao.delete(emploiDuTempsClasse);
		}
		em.remove(em.merge(matiere));
	}

	@Override
	public Matiere find(String name) {
		Query query = em.createQuery("from Matiere m where m.nom = :nom");
		query.setParameter("nom", name);
		List<Matiere> matiere = query.getResultList();
		return matiere.size() > 0 ? matiere.get(0) : null;
	}
	
	
}
