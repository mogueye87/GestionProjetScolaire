package GestionScolaire.metier.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import GestionScolaire.metier.dao.ClasseDao;
import GestionScolaire.metier.dao.EmploiDuTempsClasseDao;
import GestionScolaire.metier.model.Classe;
import GestionScolaire.metier.model.EmploiDuTempsClasse;
import GestionScolaire.metier.model.Matiere;
import GestionScolaire.metier.model.MatiereSalle;
import GestionScolaire.metier.model.ProfesseurMatiere;

@Transactional
@Repository
public class ClasseDaoJpa implements ClasseDao {

	@PersistenceContext // annotation jpa qui injecte automatiquement l'entity
	// manager
	private EntityManager em;

	@Autowired
	private EmploiDuTempsClasseDao emploiDuTempsClasseDao;
	
	@Override
	public Classe find(Long id) {
		return em.find(Classe.class, id);
	}

	@Override
	public List<Classe> findAll() {
		Query query = em.createQuery("from Classe c");
		return query.getResultList();
	}

	@Override
	public void create(Classe classe) {
		em.persist(classe);
		
	}

	@Override
	public Classe update(Classe classe) {
		return em.merge(classe);
	}

	@Override
	public void delete(Classe classe) {
		
		for (EmploiDuTempsClasse emploiDuTempsClasse : classe.getEmploiDuTempsClasses()) {
			emploiDuTempsClasseDao.delete(emploiDuTempsClasse);
		}
		
		em.remove(em.merge(classe));
		
	}

	@Override
	public void delete(Long id) {
		Classe classe = find(id);
		for (EmploiDuTempsClasse emploiDuTempsClasse : classe.getEmploiDuTempsClasses()) {
			emploiDuTempsClasseDao.delete(emploiDuTempsClasse);
		}
		em.remove(em.merge(classe));
	}

	@Override
	public Classe find(String name) {
		Query query = em.createQuery("from Classe c where m.nom = :nom");
		query.setParameter("nom", name);
		List<Classe> classe = query.getResultList();
		return classe.size() > 0 ? classe.get(0) : null;
	}

}
