package GestionScolaire.metier.dao;

import GestionScolaire.metier.model.Professeur;

public interface ProfesseurDao extends Dao<Professeur,Long>{

	Professeur find(String name);

}
