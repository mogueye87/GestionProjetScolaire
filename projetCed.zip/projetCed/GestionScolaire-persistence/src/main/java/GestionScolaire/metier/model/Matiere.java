package GestionScolaire.metier.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Version;

@Entity
public class Matiere {

	private Long id;
	private String nom;
	private CouleurMatiere couleur;
	private List<MatiereSalle> salles;
	private List<ProfesseurMatiere> professeurs;
	private List<EmploiDuTempsClasse> emploiDuTempsClasses;
	private int version;
	
	
	
	public Matiere(String nom, CouleurMatiere couleur, List<MatiereSalle> salles, List<ProfesseurMatiere> professeurs,
			List<EmploiDuTempsClasse> emploiDuTempsClasses) {
		super();
		this.nom = nom;
		this.couleur = couleur;
		this.salles = salles;
		this.professeurs = professeurs;
		this.emploiDuTempsClasses = emploiDuTempsClasses;
	}

	public Matiere() {
		super();
	}
	
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "nom", length = 100)
	public String getNom() {
		return nom;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public CouleurMatiere getCouleur() {
		return couleur;
	}
	
	public void setCouleur(CouleurMatiere couleur) {
		this.couleur = couleur;
	}
	
	
	
	@OneToMany(mappedBy = "matiere", fetch = FetchType.EAGER)	
	public List<MatiereSalle> getSalles() {
		return salles;
	}

	public void setSalles(List<MatiereSalle> salles) {
		this.salles = salles;
	}

	@OneToMany(mappedBy = "matiere", fetch = FetchType.EAGER)	
	public List<ProfesseurMatiere> getProfesseurs() {
		return professeurs;
	}
	
	public void setProfesseurs(List<ProfesseurMatiere> professeurs) {
		this.professeurs = professeurs;
	}

	@Version
	public int getVersion() {
		return version;
	}
	
	public void setVersion(int version) {
		this.version = version;
	}

	@OneToMany(mappedBy = "matiere", fetch = FetchType.EAGER)
	public List<EmploiDuTempsClasse> getEmploiDuTempsClasses() {
		return emploiDuTempsClasses;
	}

	public void setEmploiDuTempsClasses(List<EmploiDuTempsClasse> emploiDuTempsClasses) {
		this.emploiDuTempsClasses = emploiDuTempsClasses;
	}
	
	
	
	
}
