package GestionScolaire.metier.model;

public enum CouleurMatiere {

	Rose,Bleu,Vert,Rouge,Orange,Jaune
}
