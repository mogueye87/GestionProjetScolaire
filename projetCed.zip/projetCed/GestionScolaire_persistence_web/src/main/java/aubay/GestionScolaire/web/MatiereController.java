package aubay.GestionScolaire.web;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import GestionScolaire.metier.dao.MatiereDao;
import GestionScolaire.metier.dao.MatiereProfesseurDao;
import GestionScolaire.metier.dao.MatiereSalleDao;
import GestionScolaire.metier.dao.ProfesseurDao;
import GestionScolaire.metier.model.CouleurMatiere;
import GestionScolaire.metier.model.Matiere;

@Controller
@RequestMapping("/matiere")
public class MatiereController {
	
	//Importation des DAO n�cessaires
	@Autowired
	private MatiereDao matiereDao;
	
	@Autowired
	private MatiereSalleDao matiereSalleDao ;
	
	@Autowired
	private MatiereProfesseurDao  matiereProfesseurDao;
	
	//R�cup�ration de la liste des mati�res
	@RequestMapping("/list")
	public String list(Model model) {
		List<Matiere> matieres = matiereDao.findAll();
		
		
		model.addAttribute("matieres", matieres);
		
		return "matiere/matieres";
	}

	
	
	//Ajout d'une mati�re
	@RequestMapping("/add")
	public String add(Model model) {
		model.addAttribute("matiere",new Matiere());
		model.addAttribute("couleurs", CouleurMatiere.values());
		
		return "matiere/matiereEdit";
	}
	
	
	//Modification d'une mati�re
	@RequestMapping("/edit")
	public String edit(@RequestParam(name="id",required=true) Long id, Model model) {
		//Identification de la mati�re � modifier
		Matiere matiere = matiereDao.find(id);
		
		model.addAttribute("matiere",matiere);
		model.addAttribute("couleurs", CouleurMatiere.values());
		
		return "matiere/matiereEdit";
	}
	
	
	//Suppression d'une mati�re
		@RequestMapping(value="/delete", method=RequestMethod.GET)
		public String delete(@RequestParam(name="id", required=true)Long id){
			
			//Identification de la mati�re � supprimer
			Matiere matiere = matiereDao.find(id);
			matiereDao.delete(matiere);
			
			return "forward:list";
		}
	
	//Sauvegarde d'une mati�re
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String save(@ModelAttribute("matiere") @Valid Matiere matiere, BindingResult result){
		//Interception des erreurs de saisie
		if(result.hasErrors()) return "matiere/matiereEdit";

		if(matiere.getId() == null) {
			matiereDao.create(matiere);
		}
		else {
			matiereDao.update(matiere);
		}

		return  "redirect:list";
	}
}
