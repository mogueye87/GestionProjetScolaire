package aubay.GestionScolaire.web;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import GestionScolaire.metier.dao.ClasseDao;
import GestionScolaire.metier.dao.ProfesseurDao;
import GestionScolaire.metier.model.Classe;
import GestionScolaire.metier.model.Professeur;
@Controller
@RequestMapping("/classe")
public class ClasseController {

	@Autowired
	private ClasseDao classeDao;
	@Autowired
	private ProfesseurDao professeurDao ;
	
	
	
	@RequestMapping("/list")
	public String list(Model model) {
		List<Classe> classes = classeDao.findAll();
		
		model.addAttribute("classes", classes);
		
		return "classe/classes";
	}
	
	@RequestMapping("/add")
	public String add(Model model) {
		model.addAttribute("classe",new Classe());
		
		List<Professeur> professeurs = professeurDao.findAll();
		model.addAttribute("professeurs", professeurs);
		
		return "classe/classeEdit";
	}
	
	@RequestMapping("/edit")
	public String edit(@RequestParam(name="id", required=true) Long id, Model model) {
		List<Professeur> professeurs = professeurDao.findAll();
		model.addAttribute("professeurs", professeurs);
		
		Classe classe = classeDao.find(id);
		model.addAttribute("classe",classe);		
		
		return "classe/classeEdit";
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String save(@ModelAttribute("classe") @Valid Classe classe, BindingResult result) {
		
		if(result.hasErrors()) {
			return "classe/classeEdit";
		}
		
		if(classe.getId() == null) {
			classeDao.create(classe);
		} else {
			classeDao.update(classe);
		}
		 
		return "redirect:list";
	}
	
	@RequestMapping(value="/delete")
	public String delete(@RequestParam(name="id", required=true) Long id) {
		Classe classe = classeDao.find(id);
		classeDao.delete(classe);
		
		return "forward:list";
	}
	
}
