package aubay.GestionScolaire.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import GestionScolaire.metier.dao.MatiereDao;
import GestionScolaire.metier.dao.MatiereProfesseurDao;
import GestionScolaire.metier.dao.PersonneDao;
import GestionScolaire.metier.dao.ProfesseurDao;
import GestionScolaire.metier.model.Civilite;
import GestionScolaire.metier.model.Personne;
import GestionScolaire.metier.model.Professeur;
import GestionScolaire.metier.model.ProfesseurMatiere;

@Controller
@RequestMapping("/professeurMatiere")
public class ProfesseurMatiereController {
	
	@Autowired
	private MatiereProfesseurDao matiereProfesseurDao;
	
	@Autowired
	private PersonneDao personneDao;
	
	@Autowired
	private ProfesseurDao professeurDao;
	
	@Autowired
	private MatiereDao matiereDao;
	
//	@RequestMapping("/list")
//	public String list(Model model){
//		List<ProfesseurMatiere> professeurMatieres = matiereProfesseurDao.findAll();
//				
//		
//		model.addAttribute("professeurMatieres", professeurMatieres);
//		
//		
//		return "professeurMatiere/professeurMatieres";
//	}
	
	@RequestMapping("/add")
	public String addProf(Model model){
		
		model.addAttribute("professeurMatiere", new ProfesseurMatiere());
		model.addAttribute("matieres", matiereDao.findAll());
		
		
		
		return "professeurMatiere/professeurMatiereEdit";
	}
	
	@RequestMapping("/edit")
	public String edit(@RequestParam(name = "id", required = true) Long id, Model model){
		
		ProfesseurMatiere professeurMatiere = matiereProfesseurDao.find(id);
		model.addAttribute("professeurMatiere", professeurMatiere);
		model.addAttribute("matieres", matiereDao.findAll());
		return "professeurMatiere/professeurMatiereEdit";
	}	
	
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String save(@ModelAttribute("professeurMatiere") ProfesseurMatiere professeurMatiere) {
		
			if (professeurMatiere.getId() == null){
				matiereProfesseurDao.create(professeurMatiere);
			}
			else matiereProfesseurDao.update(professeurMatiere);
		
	return "redirect:../personne/listProf";
	}

		
//	@RequestMapping(value="/save", method=RequestMethod.POST)
//	public String save(@ModelAttribute("professeurMatieres") List<ProfesseurMatiere> professeurMatieres) {
//		for (int i = 0; i<professeurMatieres.size(); i++){
//			//Cr�ation d'un nouvel objet Professeur
//			if (professeurMatieres.get(i).getId() == null){
//				matiereProfesseurDao.create(professeurMatieres.get(i));
//			}
//			else matiereProfesseurDao.update(professeurMatieres.get(i));
//		}
//	return "redirect:../personne/listProf";
//	}

}
