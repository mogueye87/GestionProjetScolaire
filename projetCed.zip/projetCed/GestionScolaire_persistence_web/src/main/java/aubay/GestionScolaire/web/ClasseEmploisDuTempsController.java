package aubay.GestionScolaire.web;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import GestionScolaire.metier.dao.ClasseDao;
import GestionScolaire.metier.dao.EmploiDuTempsClasseDao;
import GestionScolaire.metier.dao.MatiereDao;
import GestionScolaire.metier.dao.ProfesseurDao;
import GestionScolaire.metier.dao.SalleDao;
import GestionScolaire.metier.model.Classe;
import GestionScolaire.metier.model.EmploiDuTempsClasse;
import GestionScolaire.metier.model.JourSemaine;
import GestionScolaire.metier.model.Matiere;
import GestionScolaire.metier.model.Professeur;
import GestionScolaire.metier.model.Salle;

@Controller
@RequestMapping("/classeEmploisDuTemps")
public class ClasseEmploisDuTempsController {

	@Autowired
	private EmploiDuTempsClasseDao emploiDuTempsClasseDao;
	
	@Autowired
	private ClasseDao classeDao;
	@Autowired
	private SalleDao salledao;
	@Autowired
	private MatiereDao matiereDao;
	@Autowired
	private ProfesseurDao professeurDao;
	
	@RequestMapping("/list")
	public String list(Model model) {
		
		List<EmploiDuTempsClasse> emploiDuTempsClasses=emploiDuTempsClasseDao.findAll();
		
		
		model.addAttribute("emploiDuTempsClasses", emploiDuTempsClasses);
		
		return "classeEmploisDuTemps/classeEmploisDuTemps";
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String delete(@RequestParam(name="numero", required=true)Long id){
		EmploiDuTempsClasse emploiDuTempsClasse = emploiDuTempsClasseDao.find(id);
		emploiDuTempsClasseDao.delete(emploiDuTempsClasse);
		
		return "forward:/classeEmploisDuTemps/list";
	}
	
	@RequestMapping("/add")
	public String add(Model model) {
		List<Classe> classes=classeDao.findAll();
		List<Professeur> professeurs=professeurDao.findAll();
		List<Matiere> matieres=matiereDao.findAll();
		List<Salle> salles=salledao.findAll();
		EmploiDuTempsClasse emploiDuTempsClasse=new EmploiDuTempsClasse();
		model.addAttribute("emploiDuTempsClasse",emploiDuTempsClasse);
		model.addAttribute("classes", classes);
		model.addAttribute("professeurs", professeurs);
		model.addAttribute("matieres", matieres);
		model.addAttribute("salles", salles);
		model.addAttribute("jourSemaine",JourSemaine.values());
		return "classeEmploisDuTemps/classeEmploisDuTempsEdit";
	}
	
	@RequestMapping("/edit")
	public String edit(@RequestParam(name="numero", required=true) Long id, Model model) {
		List<Classe> classes=classeDao.findAll();
		List<Professeur> professeurs=professeurDao.findAll();
		List<Matiere> matieres=matiereDao.findAll();
		List<Salle> salles=salledao.findAll();
		EmploiDuTempsClasse emploiDuTempsClasse = emploiDuTempsClasseDao.find( id);
		model.addAttribute("classes", classes);
		model.addAttribute("professeurs", professeurs);
		model.addAttribute("matieres", matieres);
		model.addAttribute("salles", salles);
		model.addAttribute("emploiDuTempsClasse",emploiDuTempsClasse);
		model.addAttribute("jourSemaine",JourSemaine.values());
		return "classeEmploisDuTemps/classeEmploisDuTempsEdit";
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public String save(@ModelAttribute("emploiDuTempsClasse") @Valid EmploiDuTempsClasse emploiDuTempsClasse, BindingResult result){
		if(result.hasErrors()) return "classeEmploisDuTemps/classeEmploisDuTempsEdit";

		if(emploiDuTempsClasse.getId() == null) emploiDuTempsClasseDao.create(emploiDuTempsClasse);
		else emploiDuTempsClasseDao.update(emploiDuTempsClasse);

		return  "redirect:list";
	}
}
