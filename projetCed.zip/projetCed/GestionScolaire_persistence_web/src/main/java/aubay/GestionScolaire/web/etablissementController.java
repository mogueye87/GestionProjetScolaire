package aubay.GestionScolaire.web;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import GestionScolaire.metier.dao.EtablissementDao;
import GestionScolaire.metier.model.Etablissement;
import GestionScolaire.metier.model.TypeEtablissement;



@Controller
@RequestMapping("/etablissement")
public class etablissementController {

	@Autowired
	private EtablissementDao etablissementDao;

	@RequestMapping("/list")
	public String list(Model model) {
		List<Etablissement> etablissements = etablissementDao.findAll();
		model.addAttribute("etablissements", etablissements);

		return "etablissement/etablissement";
	}

	@RequestMapping("/add")
	public String add(Model model) {

		model.addAttribute("etablissement", new Etablissement());
		model.addAttribute("typeEtablissements", TypeEtablissement.values());
		return "etablissement/etablissementEdit";
	}

	@RequestMapping("/edit")
	public String edit(@RequestParam(name = "idEtablissement", required = true) Long idEtablissement, Model model) {
		Etablissement etablissement = etablissementDao.find(idEtablissement);
		model.addAttribute("etablissement", etablissement);
		model.addAttribute("typeEtablissements", TypeEtablissement.values());

		return "etablissement/etablissementEdit";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(@ModelAttribute("etablissement") Etablissement etablissement) {

		if (etablissement.getIdEtablissement() == null) {
			etablissementDao.create(etablissement);
		} else {
			etablissementDao.update(etablissement);
		}

		return "redirect:list";
	}

	@RequestMapping(value = "/delete")
	public String delete(@RequestParam(name = "idEtablissement", required = true) Long idEtablissement) {
		Etablissement etablissement = etablissementDao.find(idEtablissement);
		etablissementDao.delete(etablissement);

		return "forward:list";
	}

}
