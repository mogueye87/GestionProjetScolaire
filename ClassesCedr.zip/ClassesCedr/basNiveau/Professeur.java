package GestionScolaire.metier.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@DiscriminatorValue("Professeur")
public class Professeur extends Personne{
	
	private Date dateNaissance;
	private List<MatiereSalle> matieres;
	private List<Classe> classes;
	private List<EmploiDuTempsClasse> emploiDuTempsClasses;
	private List<ProfesseurMatiere> profMatieres;

	public Professeur() {
		super();
	}



	public Professeur(Date dateNaissance, List<MatiereSalle> matieres, List<Classe> classes,
			List<EmploiDuTempsClasse> emploiDuTempsClasses, List<ProfesseurMatiere> profMatieres) {
		super();
		this.dateNaissance = dateNaissance;
		this.matieres = matieres;
		this.classes = classes;
		this.emploiDuTempsClasses = emploiDuTempsClasses;
		this.profMatieres = profMatieres;
	}



	@Column(name = "dateNaissance")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	public Date getDateNaissance() {
		return dateNaissance;
	}
	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	@OneToMany(mappedBy = "salle", fetch = FetchType.EAGER)
	public List<MatiereSalle> getMatieres() {
		return matieres;
	}

	public void setMatieres(List<MatiereSalle> matiereSalles) {
		this.matieres = matieres;
	}
	
	@OneToMany(mappedBy = "professeur", fetch = FetchType.EAGER)
	public List<Classe> getClasses() {
		return classes;
	}

	public void setClasses(List<Classe> classes) {
		this.classes = classes;
	}

	@OneToMany(mappedBy = "professeur", fetch = FetchType.EAGER)	
	public List<EmploiDuTempsClasse> getEmploiDuTempsClasses() {
		return emploiDuTempsClasses;
	}

	public void setEmploiDuTempsClasses(List<EmploiDuTempsClasse> emploiDuTempsClasses) {
		this.emploiDuTempsClasses = emploiDuTempsClasses;
		
	}


	@OneToMany(mappedBy = "professeur", fetch = FetchType.EAGER)
	public List<ProfesseurMatiere> getProfMatieres() {
		return profMatieres;
	}



	public void setProfMatieres(List<ProfesseurMatiere> profMatieres) {
		this.profMatieres = profMatieres;
	}

	
	
	
}
