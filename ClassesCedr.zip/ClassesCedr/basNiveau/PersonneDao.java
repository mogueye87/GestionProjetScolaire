package GestionScolaire.metier.dao;

import GestionScolaire.metier.model.Personne;
import GestionScolaire.metier.model.Professeur;

public interface PersonneDao extends Dao<Personne,Long> {

	Professeur find(String name);
}
